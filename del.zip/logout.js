import { auth } from "/firebase.js";
import { onAuthStateChanged, signOut } from "https://www.gstatic.com/firebasejs/10.8.0/firebase-auth.js";

document.addEventListener("DOMContentLoaded", function() {
  const logoutButton = document.getElementById("logoutButton");
  
  // Check authentication state
  onAuthStateChanged(auth, (user) => {
    if (user) {
      const userName = user.displayName || "User"; // Get the user's name or fallback to 'User'
      logoutButton.innerHTML = `Logout (${userName})`; // Show user's name on the button
    }
  });
  
  // Logout event listener
  logoutButton.addEventListener("click", function() {
    signOut(auth)
      .then(() => {
        alert("You have logged out successfully.");
        localStorage.removeItem("userEmail"); // Clear stored session
        window.location.href = "login.html"; // Redirect to login page
      })
      .catch((error) => {
        console.error("Logout Error:", error);
      });
  });
});